<?php

// Protection against direct access
defined('_JEXEC') or die('Restricted access');
?>

<script type="text/javascript">
    function check_pm_concordpay(){
        document.querySelector('#payment_form').submit();
    }
</script>